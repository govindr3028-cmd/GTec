/**
 * Database Module for G-TEC Tripunithura Website
 * Provides persistent, atomic storage for enquiries, contact messages, and certificate verification.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const ENQUIRIES_FILE = path.join(DATA_DIR, 'enquiries.json');
const CONTACTS_FILE = path.join(DATA_DIR, 'contacts.json');
const CERTS_FILE = path.join(DATA_DIR, 'certificates.json');

// Ensure directory and files exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function initFile(file, defaultData) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify(defaultData, null, 2), 'utf8');
  }
}

// Initial sample certificate verification database
const initialCerts = [
  {
    certNumber: "GTEC-2025-KL-8910",
    studentName: "Akhil S.",
    course: "Python Full Stack Development",
    grade: "A+ (Distinction)",
    issueDate: "2025-11-20",
    center: "Tripunithura Campus (Code: KL-TRP-042)",
    status: "Verified & Valid",
    duration: "6 Months",
    accreditation: "ISO 9001:2015 & NSDC Aligned"
  },
  {
    certNumber: "GTEC-2026-TR-1024",
    studentName: "Reshma N.",
    course: "DIA - Diploma in International Accounting",
    grade: "A (Distinction)",
    issueDate: "2026-02-15",
    center: "Tripunithura Campus (Code: KL-TRP-042)",
    status: "Verified & Valid",
    duration: "6 Months",
    accreditation: "Tally Education Authorized & ISO 9001:2015"
  },
  {
    certNumber: "GTEC-2025-TR-3391",
    studentName: "Vishnu Kumar",
    course: "Master Diploma in Architectural CADD & BIM",
    grade: "A+ (Distinction)",
    issueDate: "2025-10-05",
    center: "Tripunithura Campus (Code: KL-TRP-042)",
    status: "Verified & Valid",
    duration: "6 Months",
    accreditation: "Autodesk Authorized Training & G-CADD"
  }
];

// Initial sample inquiries for admin demo
const initialEnquiries = [
  {
    id: "ENQ-1001",
    name: "Sujith M. Menon",
    phone: "9847123456",
    email: "sujith.menon@gmail.com",
    course: "Python Full Stack Development",
    comments: "Interested in the upcoming weekend batch. Please share fee structure.",
    mode: "Weekend",
    status: "New",
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    notes: ""
  },
  {
    id: "ENQ-1002",
    name: "Ananya Pillai",
    phone: "9495678901",
    email: "ananya.p@outlook.com",
    course: "DIA - Diploma in International Accounting",
    comments: "Completed B.Com last year. Looking for GCC VAT and TallyPrime training with Gulf placement.",
    mode: "Classroom",
    status: "Contacted",
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    notes: "Spoke to student. Scheduled demo class for Saturday."
  }
];

initFile(ENQUIRIES_FILE, initialEnquiries);
initFile(CONTACTS_FILE, []);
initFile(CERTS_FILE, initialCerts);

function readJson(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error reading ${file}:`, err);
    return [];
  }
}

function writeJson(file, data) {
  const tempFile = `${file}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tempFile, file);
}

module.exports = {
  // Enquiries
  getEnquiries() {
    return readJson(ENQUIRIES_FILE);
  },
  addEnquiry(enquiry) {
    const list = readJson(ENQUIRIES_FILE);
    const newEnquiry = {
      id: `ENQ-${Date.now().toString().slice(-5)}`,
      status: "New",
      createdAt: new Date().toISOString(),
      notes: "",
      ...enquiry
    };
    list.unshift(newEnquiry);
    writeJson(ENQUIRIES_FILE, list);
    return newEnquiry;
  },
  updateEnquiry(id, updates) {
    const list = readJson(ENQUIRIES_FILE);
    const idx = list.findIndex(e => e.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...updates, updatedAt: new Date().toISOString() };
    writeJson(ENQUIRIES_FILE, list);
    return list[idx];
  },
  deleteEnquiry(id) {
    const list = readJson(ENQUIRIES_FILE);
    const filtered = list.filter(e => e.id !== id);
    if (filtered.length === list.length) return false;
    writeJson(ENQUIRIES_FILE, filtered);
    return true;
  },

  // Contact Messages
  getContacts() {
    return readJson(CONTACTS_FILE);
  },
  addContact(contact) {
    const list = readJson(CONTACTS_FILE);
    const item = {
      id: `MSG-${Date.now().toString().slice(-5)}`,
      createdAt: new Date().toISOString(),
      ...contact
    };
    list.unshift(item);
    writeJson(CONTACTS_FILE, list);
    return item;
  },

  // Certificate Verification
  verifyCertificate(certNumber) {
    if (!certNumber) return null;
    const cleanNumber = certNumber.trim().toUpperCase();
    const certs = readJson(CERTS_FILE);
    return certs.find(c => c.certNumber.toUpperCase() === cleanNumber) || null;
  }
};
