/**
 * G-TEC Computer Education - Tripunithura Campus
 * Core Interactions, Dynamic Components, and Full-Stack APIs
 */

document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initStatsCounters();
  initCoursesGrid();
  initCourseModal();
  initQuizAdvisor();
  initFaqAccordion();
  initEnquiryModal();
  initContactForms();
  initScrollEffects();
});

/* -------------------------------------------------------------
   Navigation & Mobile Menu
------------------------------------------------------------- */
function initNavbar() {
  const header = document.querySelector('.main-header');
  const toggleBtn = document.querySelector('.mobile-toggle');
  const navMenu = document.querySelector('.navbar-nav');
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });

  if (toggleBtn && navMenu) {
    toggleBtn.addEventListener('click', () => {
      navMenu.classList.toggle('open');
    });

    document.addEventListener('click', (e) => {
      if (!navMenu.contains(e.target) && !toggleBtn.contains(e.target) && navMenu.classList.contains('open')) {
        navMenu.classList.remove('open');
      }
    });

    const dropdownItems = document.querySelectorAll('.nav-item.has-dropdown');
    dropdownItems.forEach(item => {
      const link = item.querySelector('.nav-link');
      if (link) {
        link.addEventListener('click', (e) => {
          if (window.innerWidth <= 768) {
            e.preventDefault();
            item.classList.toggle('dropdown-open');
          }
        });
      }
    });
  }
}

/* -------------------------------------------------------------
   Animated Stats Counters
------------------------------------------------------------- */
function initStatsCounters() {
  const statNumbers = document.querySelectorAll('.counter-val');
  let animated = false;

  const runAnimation = () => {
    statNumbers.forEach(el => {
      const target = parseInt(el.getAttribute('data-target') || '0', 10);
      const suffix = el.getAttribute('data-suffix') || '';
      let current = 0;
      const step = Math.max(1, Math.floor(target / 45));

      const timer = setInterval(() => {
        current += step;
        if (current >= target) {
          el.textContent = target + suffix;
          clearInterval(timer);
        } else {
          el.textContent = current + suffix;
        }
      }, 30);
    });
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !animated) {
        animated = true;
        runAnimation();
      }
    });
  }, { threshold: 0.3 });

  const statsSection = document.querySelector('.stats-section');
  if (statsSection) {
    observer.observe(statsSection);
  }
}

/* -------------------------------------------------------------
   Courses Rendering, Filtering & Search
------------------------------------------------------------- */
function initCoursesGrid() {
  const container = document.getElementById('coursesContainer');
  if (!container || typeof coursesData === 'undefined') return;

  const filterBtns = document.querySelectorAll('.filter-btn');
  const searchInput = document.getElementById('courseSearchInput');
  const heroSearchInput = document.getElementById('heroSearchInput');
  const countBadge = document.getElementById('coursesCount');

  let activeCategory = 'all';
  let searchTerm = '';

  function renderCourses() {
    let filtered = coursesData.filter(course => {
      const matchesCategory = activeCategory === 'all' || course.category === activeCategory;
      const matchesSearch = !searchTerm || 
        course.title.toLowerCase().includes(searchTerm) || 
        course.tools.some(t => t.toLowerCase().includes(searchTerm)) ||
        course.shortDesc.toLowerCase().includes(searchTerm);
      return matchesCategory && matchesSearch;
    });

    if (countBadge) {
      countBadge.textContent = `${filtered.length} Programs Available`;
    }

    if (filtered.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
          <i class="fa-solid fa-graduation-cap" style="font-size: 3rem; color: var(--text-light); margin-bottom: 16px;"></i>
          <h4 style="font-size: 1.4rem; color: var(--dark); margin-bottom: 8px;">No matching courses found</h4>
          <p style="color: var(--text-muted); max-width: 450px; margin: 0 auto 20px;">
            Can't find what you're looking for? Reach out to our Tripunithura student counsellor directly.
          </p>
          <button class="btn btn-primary" onclick="openEnquiryModal('General Course Enquiry')">Ask Counsellor</button>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(course => `
      <div class="course-card" data-id="${course.id}">
        <div class="course-card-header">
          <span class="course-category-badge">${course.categoryName}</span>
          <h3 class="course-card-title">${course.title}</h3>
          <p class="course-card-desc">${course.shortDesc}</p>
        </div>
        
        <div class="course-meta">
          <div class="course-meta-item">
            <i class="fa-regular fa-clock"></i>
            <span>${course.duration.split('(')[0]}</span>
          </div>
          <div class="course-meta-item">
            <i class="fa-solid fa-star" style="color: #f59e0b;"></i>
            <span>${course.rating} (${course.reviewsCount}+)</span>
          </div>
        </div>

        <div class="course-tools-wrapper">
          <div class="course-tools-title">Tools & Frameworks</div>
          <div class="tools-pill-group">
            ${course.tools.slice(0, 5).map(tool => `<span class="tool-pill">${tool}</span>`).join('')}
            ${course.tools.length > 5 ? `<span class="tool-pill">+${course.tools.length - 5} more</span>` : ''}
          </div>
        </div>

        <div class="course-card-footer">
          <button class="btn-details" onclick="openCourseDetails('${course.id}')">
            Syllabus & Details <i class="fa-solid fa-arrow-right"></i>
          </button>
          <button class="btn btn-sm btn-secondary" onclick="openEnquiryModal('${course.title}')">
            Enquire
          </button>
        </div>
      </div>
    `).join('');
  }

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = btn.getAttribute('data-filter') || 'all';
      renderCourses();
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchTerm = e.target.value.toLowerCase().trim();
      renderCourses();
    });
  }

  if (heroSearchInput) {
    heroSearchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        searchTerm = heroSearchInput.value.toLowerCase().trim();
        const catalogEl = document.getElementById('coursesCatalog');
        if (catalogEl) {
          catalogEl.scrollIntoView({ behavior: 'smooth' });
        }
        if (searchInput) {
          searchInput.value = heroSearchInput.value;
        }
        renderCourses();
      }
    });

    const heroSearchBtn = document.getElementById('heroSearchBtn');
    if (heroSearchBtn) {
      heroSearchBtn.addEventListener('click', () => {
        searchTerm = heroSearchInput.value.toLowerCase().trim();
        const catalogEl = document.getElementById('coursesCatalog');
        if (catalogEl) {
          catalogEl.scrollIntoView({ behavior: 'smooth' });
        }
        if (searchInput) {
          searchInput.value = heroSearchInput.value;
        }
        renderCourses();
      });
    }
  }

  renderCourses();
}

/* -------------------------------------------------------------
   Course Details Modal
------------------------------------------------------------- */
function initCourseModal() {
  const modal = document.getElementById('courseDetailModal');
  const closeBtn = document.getElementById('closeCourseModal');
  if (!modal) return;

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      modal.classList.remove('show');
    });
  }

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('show');
    }
  });
}

window.openCourseDetails = function(courseId) {
  if (typeof coursesData === 'undefined') return;
  const course = coursesData.find(c => c.id === courseId);
  if (!course) return;

  const modal = document.getElementById('courseDetailModal');
  const titleEl = document.getElementById('modalCourseTitle');
  const catEl = document.getElementById('modalCourseCategory');
  const descEl = document.getElementById('modalCourseDesc');
  const durationEl = document.getElementById('modalCourseDuration');
  const modeEl = document.getElementById('modalCourseMode');
  const eligEl = document.getElementById('modalCourseElig');
  const syllabusList = document.getElementById('modalCourseSyllabus');
  const toolsList = document.getElementById('modalCourseTools');
  const careersList = document.getElementById('modalCourseCareers');
  const certsList = document.getElementById('modalCourseCerts');
  const whatsappBtn = document.getElementById('modalCourseWhatsapp');
  const enquireBtn = document.getElementById('modalCourseEnquireBtn');

  if (titleEl) titleEl.textContent = course.title;
  if (catEl) catEl.textContent = course.categoryName;
  if (descEl) descEl.textContent = course.description;
  if (durationEl) durationEl.textContent = course.duration;
  if (modeEl) modeEl.textContent = course.mode;
  if (eligEl) eligEl.textContent = course.eligibility;

  if (syllabusList) {
    syllabusList.innerHTML = course.syllabus.map(mod => `
      <li style="margin-bottom: 8px; display: flex; align-items: flex-start; gap: 8px; font-size: 0.92rem; color: var(--text-main);">
        <i class="fa-solid fa-circle-check" style="color: var(--primary); margin-top: 4px;"></i>
        <span>${mod}</span>
      </li>
    `).join('');
  }

  if (toolsList) {
    toolsList.innerHTML = course.tools.map(tool => `
      <span class="tool-pill" style="padding: 5px 12px; font-size: 0.82rem;">${tool}</span>
    `).join('');
  }

  if (careersList) {
    careersList.innerHTML = course.careers.map(car => `
      <li style="margin-bottom: 6px; font-size: 0.9rem; color: var(--text-main);">
        <i class="fa-solid fa-briefcase" style="color: var(--secondary); margin-right: 6px;"></i> ${car}
      </li>
    `).join('');
  }

  if (certsList) {
    certsList.innerHTML = course.certifications.map(cert => `
      <span class="badge badge-primary" style="font-size: 0.8rem; margin-right: 6px; margin-bottom: 6px;">${cert}</span>
    `).join('');
  }

  if (whatsappBtn) {
    const text = encodeURIComponent(`Hi G-TEC Tripunithura, I am interested in syllabus and fee details for ${course.title}.`);
    whatsappBtn.href = `https://wa.me/918289869975?text=${text}`;
  }

  if (enquireBtn) {
    enquireBtn.onclick = () => {
      modal.classList.remove('show');
      openEnquiryModal(course.title);
    };
  }

  modal.classList.add('show');
};

/* -------------------------------------------------------------
   Interactive Career Advisor Quiz
------------------------------------------------------------- */
function initQuizAdvisor() {
  const steps = document.querySelectorAll('.quiz-step');
  if (steps.length === 0) return;

  let currentStep = 1;
  let userEducation = '';
  let userGoal = '';

  const showStep = (num) => {
    steps.forEach(s => s.classList.remove('active'));
    const target = document.querySelector(`.quiz-step[data-step="${num}"]`);
    if (target) target.classList.add('active');
  };

  const eduOptions = document.querySelectorAll('.quiz-option-card[data-type="edu"]');
  eduOptions.forEach(card => {
    card.addEventListener('click', () => {
      eduOptions.forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      userEducation = card.getAttribute('data-val');
      document.getElementById('quizNext1').disabled = false;
    });
  });

  const next1 = document.getElementById('quizNext1');
  if (next1) {
    next1.addEventListener('click', () => {
      if (!userEducation) return;
      currentStep = 2;
      showStep(2);
    });
  }

  const goalOptions = document.querySelectorAll('.quiz-option-card[data-type="goal"]');
  goalOptions.forEach(card => {
    card.addEventListener('click', () => {
      goalOptions.forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      userGoal = card.getAttribute('data-val');
      document.getElementById('quizSubmit').disabled = false;
    });
  });

  const prev2 = document.getElementById('quizPrev2');
  if (prev2) {
    prev2.addEventListener('click', () => {
      currentStep = 1;
      showStep(1);
    });
  }

  const submitQuiz = document.getElementById('quizSubmit');
  if (submitQuiz) {
    submitQuiz.addEventListener('click', async () => {
      if (!userGoal) return;
      
      // Try backend recommendation API
      try {
        const res = await fetch('/api/quiz-recommend', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ education: userEducation, goal: userGoal })
        });
        const data = await res.json();
        if (data.success && data.recommendation) {
          const rec = data.recommendation;
          document.getElementById('quizRecTitle').textContent = rec.title;
          document.getElementById('quizRecDesc').textContent = rec.reason;
        } else {
          fallbackRecommendation(userEducation, userGoal);
        }
      } catch (e) {
        fallbackRecommendation(userEducation, userGoal);
      }

      currentStep = 3;
      showStep(3);
    });
  }

  const restartQuiz = document.getElementById('quizRestart');
  if (restartQuiz) {
    restartQuiz.addEventListener('click', () => {
      userEducation = '';
      userGoal = '';
      eduOptions.forEach(c => c.classList.remove('selected'));
      goalOptions.forEach(c => c.classList.remove('selected'));
      if (next1) next1.disabled = true;
      if (submitQuiz) submitQuiz.disabled = true;
      currentStep = 1;
      showStep(1);
    });
  }

  function fallbackRecommendation(edu, goal) {
    let recCourse = "Python Full Stack Development";
    let desc = "Combines high salary potential in Kochi Infopark with strong international demand.";

    if (goal === 'accounting' || edu === 'commerce') {
      recCourse = "DIA - Diploma in International Accounting & SAP FICO";
      desc = "Includes TallyPrime, GST, Gulf VAT, and SAP FICO for immediate placements in Kerala and GCC.";
    } else if (goal === 'creative') {
      recCourse = "UI/UX Design Master & Motion Graphics";
      desc = "High-growth creative career crafting digital apps, Figma prototypes, and branding assets.";
    } else if (goal === 'gulf') {
      if (edu === 'engineering') {
        recCourse = "Master Diploma in Architectural CADD & BIM (Revit)";
        desc = "In tremendous demand for major construction and consultancy firms across GCC and Bangalore.";
      } else {
        recCourse = "Diploma in International Accounting (GCC VAT & TallyPrime)";
        desc = "Guaranteed pathway to Gulf corporate accounting with practical tax compliance.";
      }
    }

    const titleEl = document.getElementById('quizRecTitle');
    const descEl = document.getElementById('quizRecDesc');
    const enquireBtn = document.getElementById('quizRecEnquireBtn');

    if (titleEl) titleEl.textContent = recCourse;
    if (descEl) descEl.textContent = desc;
    if (enquireBtn) {
      enquireBtn.onclick = () => openEnquiryModal(recCourse);
    }
  }
}

/* -------------------------------------------------------------
   FAQ Accordion
------------------------------------------------------------- */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', () => {
        const isOpen = item.classList.contains('active');
        faqItems.forEach(i => i.classList.remove('active'));
        if (!isOpen) {
          item.classList.add('active');
        }
      });
    }
  });
}

/* -------------------------------------------------------------
   Quick Enquiry Modal
------------------------------------------------------------- */
function initEnquiryModal() {
  const modal = document.getElementById('enquiryModal');
  const closeBtn = document.getElementById('closeEnquiryModal');
  const triggers = document.querySelectorAll('.trigger-enquiry');

  triggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const course = btn.getAttribute('data-course') || 'General Enquiry';
      openEnquiryModal(course);
    });
  });

  if (closeBtn && modal) {
    closeBtn.addEventListener('click', () => {
      modal.classList.remove('show');
    });
  }

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('show');
      }
    });
  }
}

window.openEnquiryModal = function(courseName = '') {
  const modal = document.getElementById('enquiryModal');
  const select = document.getElementById('enquiryCourseSelect');
  if (modal) {
    if (select && courseName) {
      let found = false;
      for (let i = 0; i < select.options.length; i++) {
        if (select.options[i].text.toLowerCase().includes(courseName.toLowerCase()) || 
            select.options[i].value.toLowerCase().includes(courseName.toLowerCase())) {
          select.selectedIndex = i;
          found = true;
          break;
        }
      }
      if (!found && courseName) {
        const opt = new Option(courseName, courseName, true, true);
        select.add(opt);
      }
    }
    modal.classList.add('show');
  }
};

/* -------------------------------------------------------------
   Contact and Enquiry Forms Submission Handlers (Real Backend API)
------------------------------------------------------------- */
function initContactForms() {
  const submitToBackend = async (form, endpoint) => {
    const formData = new FormData(form);
    const dataObj = Object.fromEntries(formData.entries());

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : 'Submit';
    if (submitBtn) {
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
      submitBtn.disabled = true;
    }

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataObj)
      });
      const result = await response.json();

      if (submitBtn) {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
      }

      if (result.success) {
        showSuccessModal(result.message || 'Thank you! Your submission has been received.', result.enquiryId || result.messageId, dataObj);
        form.reset();
        const enquiryModal = document.getElementById('enquiryModal');
        if (enquiryModal) enquiryModal.classList.remove('show');
      } else {
        alert(result.message || 'Submission error. Please try again.');
      }
    } catch (err) {
      // Offline fallback
      if (submitBtn) {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
      }
      alert(`Thank you, ${dataObj.name || 'Student'}!\nYour message for ${dataObj.course || 'Admissions'} has been recorded. Our Tripunithura campus advisor will call you at ${dataObj.phone} shortly.`);
      form.reset();
      const enquiryModal = document.getElementById('enquiryModal');
      if (enquiryModal) enquiryModal.classList.remove('show');
    }
  };

  const mainContactForm = document.getElementById('mainContactForm');
  if (mainContactForm) {
    mainContactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      submitToBackend(mainContactForm, '/api/enquiries');
    });
  }

  const modalEnquiryForm = document.getElementById('modalEnquiryForm');
  if (modalEnquiryForm) {
    modalEnquiryForm.addEventListener('submit', (e) => {
      e.preventDefault();
      submitToBackend(modalEnquiryForm, '/api/enquiries');
    });
  }
}

function showSuccessModal(message, refId, data) {
  let modal = document.getElementById('feedbackModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'feedbackModal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  const waText = encodeURIComponent(`Hi G-TEC Tripunithura, I just submitted an enquiry for ${data.course || 'a course'} (Ref: ${refId || 'N/A'}).`);
  const waUrl = `https://wa.me/918289869975?text=${waText}`;

  modal.innerHTML = `
    <div class="modal-dialog-box" style="max-width: 500px; text-align: center; padding: 35px 25px;">
      <div style="width: 70px; height: 70px; border-radius: 50%; background: #dcfce7; color: #16a34a; font-size: 2.2rem; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
        <i class="fa-solid fa-circle-check"></i>
      </div>
      <h3 style="font-size: 1.6rem; color: var(--dark); margin-bottom: 8px;">Enquiry Submitted!</h3>
      <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 16px;">${message}</p>
      
      ${refId ? `
        <div style="background: var(--bg-subtle); padding: 10px 18px; border-radius: 8px; display: inline-block; margin-bottom: 24px; font-family: monospace; font-weight: 700; color: var(--primary);">
          Application Reference: ${refId}
        </div>
      ` : ''}

      <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
        <a href="${waUrl}" target="_blank" class="btn btn-primary" style="background: #25D366; border-color: #25D366;">
          <i class="fa-brands fa-whatsapp"></i> Chat with Counsellor Now
        </a>
        <button onclick="document.getElementById('feedbackModal').classList.remove('show')" class="btn btn-outline">
          Close
        </button>
      </div>
    </div>
  `;

  modal.classList.add('show');
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('show');
  });
}

/* -------------------------------------------------------------
   Scroll Effects & Floating Actions
------------------------------------------------------------- */
function initScrollEffects() {
  const topBtn = document.getElementById('returnToTop');
  if (topBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        topBtn.classList.add('show');
      } else {
        topBtn.classList.remove('show');
      }
    });

    topBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
}
